module.exports=(sequelize,Datatypes)=>{
    const user=sequelize.define("user",{
        name:{
            type:Datatypes.STRING,
            isrequired:true
        },
        email:{
            type:Datatypes.STRING,
            isrequired:true
        }
    })
    return user;
}